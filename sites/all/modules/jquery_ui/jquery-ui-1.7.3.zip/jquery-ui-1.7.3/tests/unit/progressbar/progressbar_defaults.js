/*
 * progressbar_defaults.js
 */

var progressbar_defaults = {
	disabled: false,
	value: 0
};

commonWidgetTests('progressbar', { defaults: progressbar_defaults });
